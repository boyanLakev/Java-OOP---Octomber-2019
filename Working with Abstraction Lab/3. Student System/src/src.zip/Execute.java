public class Execute {
    private StudentSystem students;

    public Execute(){
        this.students=new StudentSystem();
    }

    public  void run(String[] args){
        if (args[0].equals("Create")) {
            String name = args[1];
            int age = Integer.parseInt(args[2]);
            double grade = Double.parseDouble(args[3]);
            if (!this.students.containsKey(name)) {
                Student student = new Student(name, age, grade);
                students.put(name, student);
            }
        } else if (args[0].equals("Show")) {
            String name = args[1];
            if (students.containsKey(name)) {
                Student student = students.get(name);


                System.out.println(student.toString());
            }
        }
    }
}

public interface Command {

    void execute(StudentRespository respository,String[] args);
}

public class Poin {
    private int coodinatX;
    private int coodinatY;

    public Poin(int coodinatX,int coodinatY){
        this.coodinatX=coodinatX;
        this.coodinatY=coodinatY;

    }

    public int getCoodinatX() {
        return coodinatX;
    }

    public int getCoodinatY() {
        return coodinatY;
    }
}

package restaurant;

import java.math.BigDecimal;

public class ColdBelerage extends Beverage {
    public ColdBelerage(String name, BigDecimal price, double mililiters) {
        super(name, price, mililiters);
    }
}

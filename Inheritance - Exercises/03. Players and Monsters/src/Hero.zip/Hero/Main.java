package Hero;

import Hero.SoulMaster;

public class Main {
    public static void main(String[] args) {
        SoulMaster soulMaster=new SoulMaster("Piano",5);
        System.out.println(soulMaster.toString());
    }
}

package Hero;

public class DarkWizard extends Wizard {
    public DarkWizard(String usename,int level){
        super(usename,level);
    }
}

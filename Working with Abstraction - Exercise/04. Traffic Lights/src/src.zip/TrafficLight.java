public enum  TrafficLight {
    GREEN,
    YELLOW,
    RED,
}

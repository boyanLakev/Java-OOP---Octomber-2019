public interface People extends Person,Buyer{
}
